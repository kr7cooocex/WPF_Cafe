﻿using Petrenko_09._24.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Petrenko_09._24.Pages
{
    /// <summary>
    /// Логика взаимодействия для OrderPage.xaml
    /// </summary>
    public partial class OrderPage : Page
    {
        private Petrenko_cafeEntities context = new Petrenko_cafeEntities();
        public OrderPage()
        {
            InitializeComponent();
            var data = context.Order.ToList(); // Внесение данных в datagrid
            dg.ItemsSource = data;
        }

        private void Create_Click(object sender, RoutedEventArgs e)
        {
            using (var context = new Petrenko_cafeEntities())
            {
                var HuntShowdown = new Order
                {
                    CompleteStatus = TbCompleteStatus.Text,    // Добавление данных в таблицу
                    Food = TbFood.Text,
                    Drink = TbDrink.Text,
                    Place = TbPlace.Text,
                    VisitorsCount = int.Parse(TbVisitorsCount.Text)
                };
                context.Order.Add(HuntShowdown);
                context.SaveChanges();


                dg.ItemsSource = null;
                var data = context.Order.ToList();  // Обновление данных в datagrid
                dg.ItemsSource = data;
            }
        }
        private void dg_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (dg.SelectedItem != null)
                {
                    var selectedRow = dg.SelectedItem as Order;
                    if (selectedRow != null)
                    {
                        TbCompleteStatus.Text = selectedRow.CompleteStatus;
                        TbFood.Text = selectedRow.Food;                //Выбор строки в datagrid
                        TbDrink.Text = selectedRow.Drink;
                        TbPlace.Text = selectedRow.Place;
                        TbVisitorsCount.Text = selectedRow.VisitorsCount.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Произошла ошибка при выборе строки: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new AdminPage());
        }
    }
}
